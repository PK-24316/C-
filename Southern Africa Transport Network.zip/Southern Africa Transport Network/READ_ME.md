# 🌍 Southern Africa Transport Network (XAI Project)

This project models a simplified transport network in **Southern Africa** using **Graph Theory**.  
Cities are represented as vertices and roads as weighted edges (in kilometers).  
It supports adjacency list and adjacency matrix representations and uses:
- **BFS** (Breadth-First Search) to show reachable cities.
- **Dijkstra’s Algorithm** to find the shortest paths between cities.

---

## 🧠 Explainable AI (XAI) Context
The project demonstrates how **AI-assisted code generation** can accelerate software development.  
AI tools were used to generate the code structure, while human oversight ensured:
- Correct graph directionality (undirected roads).
- Realistic city names and distances.
- Improved output readability and explanatory comments.

---

## ⚙️ Features
- Graph represented via adjacency list and matrix.
- BFS traversal for network reachability.
- Dijkstra’s algorithm for shortest path computation.
- Simple text-based user menu.
- Explainable AI reflection section.

---

## 🧩 Technologies Used
- **Language:** C++
- **Concepts:** Graphs, BFS, Dijkstra’s Algorithm, XAI
- **Libraries:** `<iostream>`, `<vector>`, `<map>`, `<queue>`, `<limits>`, `<iomanip>`, `<algorithm>`

---

## 🏁 How to Run
1. Open the project in Code::Blocks or any C++ compiler.
2. Compile and run the file `24654906_As3.cpp`.
3. Use the menu to:
   - View graph connections.
   - Display adjacency matrix.
   - Run BFS traversal.
   - Find shortest paths.

---

## 👨‍💻 Author
**Pholosho Kwetepane**  
COS2611 Assignment 3 — Explainable AI Approach
