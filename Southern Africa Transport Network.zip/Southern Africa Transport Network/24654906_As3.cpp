/**********************************************************************
Name: Pholosho Kwetepane
Student Number: 24654906
Module Code: COS2611
Assignment: 03
**********************************************************************/

///Libraries
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <queue>
#include <limits>
#include <iomanip>
#include <algorithm>

using namespace std;

/**
    === EXPLAINABLE AI (XAI) APPROACH ===
    This program models a simplified transport network in Southern Africa
    using Graph theory.

    - Cities are represented as vertices.
    - Roads are represented as weighted edges (distances in kilometers).
    - Graph stored in adjacency list form.
    - Also displayed in adjacency matrix form.
    - BFS used to show reachable cities.
    - Dijkstra�s algorithm used to compute shortest paths.
**/

/**
    === Graph Class Header ===
    - Represents Cities and Roads as a weighted graph.
    - Supports adjacency list, adjacency matrix, BFS, and Dijkstra.
**/

class Graph
{
private:
    int V; ///Number of vertices (cities)
    vector<vector<pair<int, int>>> adjList; ///adjacency list
    map<int, string> cityNames; ///Index -> city name

public:
    Graph(int vertices); ///Constructor

    void addCityName(int index, string name);
    void addEdge(int src, int dest, int weight);

    ///Functions to Perform certain activities
    void displayAdjMatrix();
    void BFS(int start);
    void dijkstra(int src, int dest);
    void displayGraph();

    ///Helpers for the menu system
    string getCityName(int index);
    int getCityIndex(string name);
    int getNumCities();
};

/** === Constructor ===**/
Graph::Graph(int vertices)
{
    V = vertices;
    adjList.resize(V);
}

/** === Add City Name (index -> label) === **/
void Graph::addCityName(int index, string name)
{
    cityNames[index] = name;
}

/** === Add edge between two cities with weight (undirected) === **/
void Graph::addEdge(int src, int dest, int weight)
{
    adjList[src].push_back({dest, weight});
    adjList[dest].push_back({src, weight});
}

/** === Display Adjacency Matrix === **/
void Graph::displayAdjMatrix()
{
    cout << "\nAdjacency Matrix (Distances in km):\n";
    cout << setw(12) << " ";

    for (int i = 0; i < V; i++)
    {
        cout << setw(12) << cityNames[i];
    }

    cout << "\n";

    vector<vector<int>> matrix(V, vector<int>(V, 0));

    for (int i = 0; i < V; i++)
    {
        for (auto &edge : adjList[i])
            matrix[i][edge.first] = edge.second;
    }

    for (int i = 0; i < V; i++)
    {
        cout << setw(12) << cityNames[i];
        for (int j = 0; j < V; j++)
            cout << setw(12) << matrix[i][j];
        cout << "\n";
    }

}

/** === BFS Traversal === **/
void Graph::BFS(int start)
{
    cout << "\nBFS Traversal starting from " << cityNames[start] << ":\n";

    vector<bool> visited(V, false);
    queue<int> q;

    visited[start] = true;
    q.push(start);

    while (!q.empty())
    {
        int city = q.front();
        q.pop();
        cout << cityNames[city] << " ";

        for (auto &neighbor : adjList[city])
        {
            int nextCity = neighbor.first;
            if (!visited[nextCity])
            {
                visited[nextCity] = true;
                q.push(nextCity);
            }
        }
    }

    cout << "\n";
}

/** === Dijkstra's Algorithm === **/
void Graph::dijkstra(int src, int dest)
{
    vector<int> dist(V, numeric_limits<int>::max());
    vector<int> parent(V, -1);
    vector<bool> visited(V, false);

    dist[src] = 0;

    for (int i = 0; i < V; i++)
    {
        int u = -1;
        for (int j = 0; j < V; j++)
        {
            if (!visited[j] && (u == -1 || dist[j] < dist[u]))
                u = j;
        }

        if (dist[u] == numeric_limits<int>::max()) break;
        visited[u] = true;

        for (auto &edge : adjList[u])
        {
            int v = edge.first;
            int weight = edge.second;
            if (dist[u] + weight < dist[v])
            {
                dist[v] = dist[u] + weight;
                parent[v] = u;
            }
        }
    }

    cout << "Total Distance: " << dist[dest] << " km\n";
    cout << "Path: ";

    vector<int> path;
    for (int v = dest; v != -1; v = parent[v])
    {
        path.insert(path.begin(), v);
    }

    for (size_t i = 0; i < path.size(); i++)
    {
        cout << cityNames[path[i]];
        if (i != path.size() -1) cout << " -> ";
    }

    cout << "\n";
}

/** === Display Graph Connections === **/
void Graph::displayGraph()
{
    cout << "\nSouthern Africa Transport Graph:\n";

    for (int i = 0; i < V; i++)
    {
        cout << cityNames[i] << " connects to: ";
        for (auto &edge : adjList[i])
            cout << "(" << cityNames[edge.first] << ", " << edge.second << " km) ";
        cout << "\n";
    }
}

/** === Getters for menu use === **/
string Graph::getCityName(int index)
{
    return cityNames[index];
}

int Graph::getCityIndex(string name)
{
    for (auto &p : cityNames)
        if (p.second == name) return p.first;

    return -1;
}

int Graph::getNumCities()
{
    return V;
}

void showMenu()
{
    cout << "\n==== Southern Africa Transport Menu ====\n";
    cout << "1. Display Graph Structure.\n";
    cout << "2. Display Adjacency Matrix.\n";
    cout << "3. BFS Traversal.\n";
    cout << "4. Shortest Path (Dijkstra).\n";
    cout << "5. Exit.\n";
    cout << "choose an option: ";
}


/** -------------------------------
    Main Function
    ------------------------------- **/

int main()
{
    Graph g(5);

    ///Add Cities
    g.addCityName(0, "Johannesburg");
    g.addCityName(1, "Gaborone");
    g.addCityName(2, "Harare");
    g.addCityName(3, "Maputo");
    g.addCityName(4, "Windhoek");

    ///Add roads
    g.addEdge(0, 1, 360);
    g.addEdge(0, 3, 550);
    g.addEdge(0, 4, 1200);
    g.addEdge(1, 2, 950);
    g.addEdge(2, 3, 1000);
    g.addEdge(3, 4, 1500);

    int choice;
    while (true)
    {
        showMenu();
        cin >> choice;

        if (choice == 1)
            g.displayGraph();
        else if (choice == 2)
            g.displayAdjMatrix();
        else if (choice == 3)
        {
            cout << "Enter Starting City Index (0-" << g.getNumCities()-1 << "): ";
            int start;
            cin >> start;

            if (start >= 0 && start < g.getNumCities())
                g.BFS(start);
            else
                cout << "Invalid City Index!\n";
        }
        else if (choice == 4)
        {
            cout << "Enter source city index (0-" << g.getNumCities()-1 << "): ";
            int src, dest;

            cin >> src;
            cout << "Enter destination city index (0-" << g.getNumCities()-1 << "): ";

            cin >> dest;
            if (src >= 0 && src < g.getNumCities() && dest >= 0 && dest < g.getNumCities())
                g.dijkstra(src, dest);
            else
                cout << "Invalid Input!\n";
        }
        else if (choice == 5)
        {
            cout << "Exiting program...\n";
            break;
        }
        else
        {
            cout << "Invalid Option, Try again.\n";
        }

    }

    return 0;
}

/***************************************************************
   === AI PROMPTS USED ===
   Prompt 1: "Let's code this in C++" with the assignment PDF uploaded.
   Prompt 2: "Please provide full C++ code with adjacency list, adjacency
             matrix, BFS, Dijkstra, and detailed comments for XAI."

   === REFLECTION ===
   Using AI helped speed up writing the skeleton of the program.
   The generated code needed adjustments:
   - I had to ensure the graph is undirected since roads work both ways.
   - I added realistic Southern African city names and distances.
   - AI produced correct BFS and Dijkstra structure, but I reformatted
     adjacency matrix output for readability.
   - Overall, AI was useful for structure, but I had to verify correctness
     and add proper explanatory comments to meet XAI requirements.
***************************************************************/
